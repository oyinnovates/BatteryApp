﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace Battery_Monitoring_App___Inversity
{
    public partial class MainBatteryPage : Form
    {
        public MainBatteryPage()
        {
            InitializeComponent();
        }

        private Random random = new Random();


        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();

            // Create an instance of the BatteryMoniterisation form
            BatteryMoniterisation batteryMoniterisationForm = new BatteryMoniterisation();

            // Show the BatteryMoniterisation form
            batteryMoniterisationForm.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void MainBatteryPage_Load(object sender, EventArgs e)
        {
            UpdateRandomBatteryLevel();

            UpdateRandomBatteryUsageChart();
        }

        private void UpdateRandomBatteryLevel()
        {
            // Generate a random battery level between 0 and 100
            int randomBatteryLevel = random.Next(101);
            batteryProgressBar.Value = randomBatteryLevel;
            labelBattery.Text = $"Battery Level: {randomBatteryLevel}%";
        }

        private void UpdateRandomBatteryUsageChart()
        {
            int timePeriod = 12; // Adjust the number of data points based on the desired range
            int[] batteryUsageData = GenerateRandomBatteryUsageData(timePeriod);

            chartBatteryUsage.Series.Clear();

            Series series = new Series("Battery Usage");
            series.ChartType = SeriesChartType.Column;

            DateTime currentTime = DateTime.Now;

            for (int i = 0; i < timePeriod; i++)
            {
                // Generate a time label for each data point with a 2-hour gap
                string timeLabel = currentTime.AddHours(-24 + i * 2).ToString("HH:mm");

                // Introduce a chance for low battery usage
                if (random.Next(100) < 30)
                {
                    batteryUsageData[i] = random.Next(21);
                }
                else
                {
                    batteryUsageData[i] = random.Next(81) + 20;
                }

                series.Points.AddXY(timeLabel, batteryUsageData[i]);
            }

            chartBatteryUsage.Series.Add(series);

            chartBatteryUsage.ChartAreas[0].AxisX.Title = "Time";
            chartBatteryUsage.ChartAreas[0].AxisX.Interval = 1; // Set the interval to 1 for better clarity
            chartBatteryUsage.ChartAreas[0].AxisY.Title = "Battery Level";

            chartBatteryUsage.Refresh();
        }




        private int[] GenerateRandomBatteryUsageData(int timePeriod)
        {
            int[] batteryUsageData = new int[timePeriod];

            for (int i = 0; i < timePeriod; i++)
            {
                // Generate random battery level between 0 and 100
                batteryUsageData[i] = random.Next(101);
            }

            return batteryUsageData;
        }

        private void chartBatteryUsage_Click(object sender, EventArgs e)
        {

        }
    }
}
