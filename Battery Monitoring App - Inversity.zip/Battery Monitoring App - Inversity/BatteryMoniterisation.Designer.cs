﻿namespace Battery_App_Inversity
{
    partial class BatteryMoniterisation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnUpdate = new System.Windows.Forms.Button();
            this.lblTemperature = new System.Windows.Forms.Label();
            this.lblCurrent = new System.Windows.Forms.Label();
            this.lblVoltage = new System.Windows.Forms.Label();
            this.lblChargeLevel = new System.Windows.Forms.Label();
            this.lblOptRec = new System.Windows.Forms.Label();
            this.lblBatteryEfficiency = new System.Windows.Forms.Label();
            this.btnImproveEfficiency = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(121, 29);
            this.btnUpdate.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(152, 55);
            this.btnUpdate.TabIndex = 0;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // lblTemperature
            // 
            this.lblTemperature.AutoSize = true;
            this.lblTemperature.Location = new System.Drawing.Point(115, 316);
            this.lblTemperature.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTemperature.Name = "lblTemperature";
            this.lblTemperature.Size = new System.Drawing.Size(67, 13);
            this.lblTemperature.TabIndex = 1;
            this.lblTemperature.Text = "Temperature";
            // 
            // lblCurrent
            // 
            this.lblCurrent.AutoSize = true;
            this.lblCurrent.Location = new System.Drawing.Point(118, 272);
            this.lblCurrent.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCurrent.Name = "lblCurrent";
            this.lblCurrent.Size = new System.Drawing.Size(51, 13);
            this.lblCurrent.TabIndex = 1;
            this.lblCurrent.Text = "lblCurrent";
            // 
            // lblVoltage
            // 
            this.lblVoltage.AutoSize = true;
            this.lblVoltage.Location = new System.Drawing.Point(118, 219);
            this.lblVoltage.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblVoltage.Name = "lblVoltage";
            this.lblVoltage.Size = new System.Drawing.Size(43, 13);
            this.lblVoltage.TabIndex = 1;
            this.lblVoltage.Text = "Voltage";
            // 
            // lblChargeLevel
            // 
            this.lblChargeLevel.AutoSize = true;
            this.lblChargeLevel.Location = new System.Drawing.Point(115, 163);
            this.lblChargeLevel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblChargeLevel.Name = "lblChargeLevel";
            this.lblChargeLevel.Size = new System.Drawing.Size(70, 13);
            this.lblChargeLevel.TabIndex = 1;
            this.lblChargeLevel.Text = "Charge Level";
            // 
            // lblOptRec
            // 
            this.lblOptRec.AutoSize = true;
            this.lblOptRec.Location = new System.Drawing.Point(115, 414);
            this.lblOptRec.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblOptRec.Name = "lblOptRec";
            this.lblOptRec.Size = new System.Drawing.Size(134, 13);
            this.lblOptRec.TabIndex = 2;
            this.lblOptRec.Text = "Optimum Recommendation";
            // 
            // lblBatteryEfficiency
            // 
            this.lblBatteryEfficiency.AutoSize = true;
            this.lblBatteryEfficiency.Location = new System.Drawing.Point(118, 361);
            this.lblBatteryEfficiency.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblBatteryEfficiency.Name = "lblBatteryEfficiency";
            this.lblBatteryEfficiency.Size = new System.Drawing.Size(89, 13);
            this.lblBatteryEfficiency.TabIndex = 2;
            this.lblBatteryEfficiency.Text = "Battery Efficiency";
            // 
            // btnImproveEfficiency
            // 
            this.btnImproveEfficiency.Location = new System.Drawing.Point(148, 549);
            this.btnImproveEfficiency.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnImproveEfficiency.Name = "btnImproveEfficiency";
            this.btnImproveEfficiency.Size = new System.Drawing.Size(125, 36);
            this.btnImproveEfficiency.TabIndex = 0;
            this.btnImproveEfficiency.Text = "How to Improve Efficiency";
            this.btnImproveEfficiency.UseVisualStyleBackColor = true;
            this.btnImproveEfficiency.Click += new System.EventHandler(this.btnImproveEfficiency_Click);
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(-3, 100);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(466, 427);
            this.panel1.TabIndex = 3;
            // 
            // BatteryMoniterisation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(465, 664);
            this.Controls.Add(this.lblBatteryEfficiency);
            this.Controls.Add(this.lblOptRec);
            this.Controls.Add(this.lblChargeLevel);
            this.Controls.Add(this.lblVoltage);
            this.Controls.Add(this.lblCurrent);
            this.Controls.Add(this.lblTemperature);
            this.Controls.Add(this.btnImproveEfficiency);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "BatteryMoniterisation";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Label lblTemperature;
        private System.Windows.Forms.Label lblCurrent;
        private System.Windows.Forms.Label lblVoltage;
        private System.Windows.Forms.Label lblChargeLevel;
        private System.Windows.Forms.Label lblOptRec;
        private System.Windows.Forms.Label lblBatteryEfficiency;
        private System.Windows.Forms.Button btnImproveEfficiency;
        private System.Windows.Forms.Panel panel1;
    }
}

