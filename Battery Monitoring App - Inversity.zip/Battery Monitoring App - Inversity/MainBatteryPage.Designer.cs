﻿namespace Battery_Monitoring_App___Inversity
{
    partial class MainBatteryPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.chartBatteryUsage = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.batteryProgressBar = new System.Windows.Forms.ProgressBar();
            this.labelBattery = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.chartBatteryUsage)).BeginInit();
            this.SuspendLayout();
            // 
            // chartBatteryUsage
            // 
            chartArea1.Name = "ChartArea1";
            this.chartBatteryUsage.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chartBatteryUsage.Legends.Add(legend1);
            this.chartBatteryUsage.Location = new System.Drawing.Point(74, 133);
            this.chartBatteryUsage.Name = "chartBatteryUsage";
            this.chartBatteryUsage.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.SeaGreen;
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            this.chartBatteryUsage.Series.Add(series1);
            this.chartBatteryUsage.Size = new System.Drawing.Size(340, 439);
            this.chartBatteryUsage.TabIndex = 0;
            this.chartBatteryUsage.Text = "chart1";
            this.chartBatteryUsage.Click += new System.EventHandler(this.chartBatteryUsage_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(134, 632);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(101, 35);
            this.button1.TabIndex = 1;
            this.button1.Text = "Charging Proximity";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(27, 632);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(101, 35);
            this.button2.TabIndex = 2;
            this.button2.Text = "Battery Moniterisation";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(348, 632);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(101, 35);
            this.button3.TabIndex = 3;
            this.button3.Text = "Settings";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(241, 632);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(101, 35);
            this.button4.TabIndex = 4;
            this.button4.Text = "Charging History";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(203)))), ((int)(((byte)(200)))));
            this.panel1.Location = new System.Drawing.Point(2, 591);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(475, 110);
            this.panel1.TabIndex = 5;
            // 
            // batteryProgressBar
            // 
            this.batteryProgressBar.Location = new System.Drawing.Point(74, 33);
            this.batteryProgressBar.Name = "batteryProgressBar";
            this.batteryProgressBar.Size = new System.Drawing.Size(163, 63);
            this.batteryProgressBar.TabIndex = 6;
            // 
            // labelBattery
            // 
            this.labelBattery.AutoSize = true;
            this.labelBattery.Location = new System.Drawing.Point(260, 61);
            this.labelBattery.Name = "labelBattery";
            this.labelBattery.Size = new System.Drawing.Size(35, 13);
            this.labelBattery.TabIndex = 7;
            this.labelBattery.Text = "label1";
            // 
            // MainBatteryPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(481, 703);
            this.Controls.Add(this.labelBattery);
            this.Controls.Add(this.batteryProgressBar);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.chartBatteryUsage);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "MainBatteryPage";
            this.Text = "MainBatteryPage";
            this.Load += new System.EventHandler(this.MainBatteryPage_Load);
            ((System.ComponentModel.ISupportInitialize)(this.chartBatteryUsage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataVisualization.Charting.Chart chartBatteryUsage;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ProgressBar batteryProgressBar;
        private System.Windows.Forms.Label labelBattery;
    }
}