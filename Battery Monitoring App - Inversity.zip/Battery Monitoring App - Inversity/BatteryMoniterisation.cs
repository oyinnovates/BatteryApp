﻿using System;
using System.Windows.Forms;

namespace Battery_App_Inversity
{
    public partial class BatteryMoniterisation : Form
    {
        public BatteryMoniterisation()
        {
            InitializeComponent();
        }
        private double previousChargeLevel = 100.0;
        private double previousVoltage = 12.0; // Assuming initial voltage
        private double previousCurrent = 0.0; // Assuming initial current
        private double previousTemperature = 25.0; // Assuming initial temperature

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Random random = new Random();
            double chargeLevel = Math.Max(previousChargeLevel - random.NextDouble() * 5, 0); // Decrease by a random value up to 5 OYIN
            double voltage = Math.Max(previousVoltage - random.NextDouble() * 1, 0); // Decrease by a random value up to 1
            double current = Math.Max(previousCurrent - random.NextDouble() * 0.5, 0); // Decrease by a random value up to 0.5
            double temperature = Math.Max(previousTemperature - random.NextDouble() * 2, 0); // Decrease by a random value up to 2

            // Update UI components with generated data
            lblChargeLevel.Text = $"Charge Level: {chargeLevel:F2}%";
            lblVoltage.Text = $"Voltage: {voltage:F2} V";
            lblCurrent.Text = $"Current: {current:F2} A";
            lblTemperature.Text = $"Temperature: {temperature:F2} °C";

            // Update previous values for next update
            previousChargeLevel = chargeLevel;
            previousVoltage = voltage;
            previousCurrent = current;
            previousTemperature = temperature;

            CalculateBatteryOptimization();

        }
        private void CalculateBatteryOptimization()
        {
            double chargeLevel = previousChargeLevel;
            double voltage = previousVoltage;
            double current = previousCurrent;
            double temperature = previousTemperature;

            // Calculate battery efficiency rating based on charge level and driving speed
            double batteryEfficiencyRating = CalculateEfficiencyRating(chargeLevel, current);

            // Display battery optimization recommendation based on efficiency rating
            string recommendation = GetOptimizationRecommendation(batteryEfficiencyRating);
            lblOptRec.Text = recommendation;
            

            // Display battery efficiency as a percentage
            lblBatteryEfficiency.Text = $"Efficiency: {batteryEfficiencyRating:F2}%";
        }

        // Method to calculate battery efficiency rating based on charge level and current
        private double CalculateEfficiencyRating(double chargeLevel, double current)
        {
            // Example calculation: assume higher charge levels and moderate current usage lead to better efficiency
            return (chargeLevel / 100.0) * (1 - current / 50.0) * 100;
        }

        // Method to provide optimization recommendation based on efficiency rating
        private string GetOptimizationRecommendation(double efficiencyRating)
        {
            if (efficiencyRating == 100)
            {
                return "Your battery usage is 100% efficient.\nAvoid regularly charging to 100% as this can stress the battery and reduce its overall lifespan.";
            }
            else if (efficiencyRating >= 80)
            {
                return "Your battery usage is efficient. Keep it up!\nAvoid regularly charging above 80% as this can stress the battery and reduce its overall lifespan.";              
            }
            else if (efficiencyRating >= 30)
            {
                btnImproveEfficiency.Show();
                return "You can improve your battery usage with moderate current usage.";              
            }
            else
            {
                btnImproveEfficiency.Show();
                return "Your battery usage is not efficient. Try to maintain higher charge levels and moderate current usage to prevent dropping below the  optimum 20%.";
            }
        }

        private void btnImproveEfficiency_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Drive slower.\nTake less steep roads.\nAvoid rapid acceleration and harsh braking", "Improve Battery Efficiency",MessageBoxButtons.OK);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            btnImproveEfficiency.Hide();
        }
    }
}


